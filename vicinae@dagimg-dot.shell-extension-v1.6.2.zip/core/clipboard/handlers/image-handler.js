import St from "gi://St";
import {
  bufferLikeToUint8Array,
  decodeClipboardBytes,
  getImageMimeType,
  isValidImageBuffer
} from "../../../utils/clipboard-utils.js";

const IMAGE_MIME_PREFIX = "image/";

class ImageHandler {
  mimeTypes = [
    "image/png",
    "image/jpeg",
    "image/gif",
    "image/webp"
  ];
  priority = 2;

  matchesMimeTypes(types) {
    return types.some((t) => t.startsWith(IMAGE_MIME_PREFIX));
  }

  matchesContent(content) {
    return content.startsWith("[BINARY_IMAGE:");
  }

  capture(clipboard, onResult, context) {
    if (!context) return;

    clipboard.get_content(
      St.ClipboardType.CLIPBOARD,
      "image/png",
      (_, rawContent) => {
        if (!rawContent) return;

        const data = decodeClipboardBytes(rawContent);
        if (!data || data.length === 0) {
          onResult("[IMAGE_DATA_AVAILABLE]");
          return;
        }

        const isValid = isValidImageBuffer(data);
        const mimeType = getImageMimeType(data);

        if (isValid) {
          const marker = `[BINARY_IMAGE:${mimeType}:${data.length}]`;
          context.storeBinaryData(marker, data, mimeType);
          onResult(marker);
        } else {
          onResult("[BINARY_DATA_AVAILABLE]");
        }
      }
    );
  }

  set(_clipboard, _content) {
    return false;
  }

  getMimeType(content, source) {
    if (source === "image" && content.startsWith("[BINARY_IMAGE:")) {
      const match = content.match(/^\[BINARY_IMAGE:([^:]+):/);
      return match ? match[1] : "image/png";
    }
    if (content.startsWith("data:image/")) {
      const match = content.match(/^data:(image\/[^;]+);/);
      return match ? match[1] : "image/png";
    }
    return "image/png";
  }

  toSignalPayload(event, context) {
    if (!event.content.startsWith("[BINARY_IMAGE:")) return null;

    const binaryInfo = context.getBinaryData(event.content);
    if (!binaryInfo) return null;

    return {
      content: bufferLikeToUint8Array(binaryInfo.data),
      mimeType: binaryInfo.mimeType
    };
  }
}

export {
  ImageHandler
};
