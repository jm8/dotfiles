import St from "gi://St";
import { isFileUri } from "../../../utils/clipboard-utils.js";

const MIME_TYPES = ["text/plain"];

class TextHandler {
  mimeTypes = MIME_TYPES;
  priority = 0;

  matchesMimeTypes(types) {
    return types.includes("text/plain") || types.length === 0;
  }

  matchesContent(content) {
    if (typeof content !== "string") return false;
    if (isFileUri(content)) return false;
    if (content.startsWith("[BINARY_IMAGE:") || content.startsWith("[BINARY_DATA:"))
      return false;
    return true;
  }

  capture(clipboard, onResult, _context) {
    clipboard.get_text(St.ClipboardType.CLIPBOARD, (_, text) => {
      if (text) onResult(text);
    });
    clipboard.get_text(St.ClipboardType.PRIMARY, (_, text) => {
      if (text) onResult(text);
    });
  }

  set(clipboard, content) {
    clipboard.set_text(St.ClipboardType.CLIPBOARD, content);
    clipboard.set_text(St.ClipboardType.PRIMARY, content);
    return true;
  }

  getMimeType(content) {
    if (content.includes("<") && content.includes(">") && (content.includes("<html") || content.includes("<div") || content.includes("<p"))) {
      return "text/html";
    }
    return "text/plain";
  }

  toSignalPayload(event, _context) {
    if (!event.content) return null;
    return {
      content: new TextEncoder().encode(event.content),
      mimeType: this.getMimeType(event.content)
    };
  }
}

export {
  TextHandler
};
