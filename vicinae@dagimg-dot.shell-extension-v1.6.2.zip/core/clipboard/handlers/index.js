import { FileHandler } from "./file-handler.js";
import { ImageHandler } from "./image-handler.js";
import { TextHandler } from "./text-handler.js";

import { FileHandler as FileHandler2 } from "./file-handler.js";
import { ImageHandler as ImageHandler2 } from "./image-handler.js";
import { TextHandler as TextHandler2 } from "./text-handler.js";

function createHandlers() {
  return [new ImageHandler(), new FileHandler(), new TextHandler()];
}

export {
  FileHandler2 as FileHandler,
  ImageHandler2 as ImageHandler,
  TextHandler2 as TextHandler,
  createHandlers
};
