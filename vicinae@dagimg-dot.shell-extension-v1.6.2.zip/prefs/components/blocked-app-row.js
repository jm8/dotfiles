import Adw from "gi://Adw";
import GObject from "gi://GObject";
import Gtk from "gi://Gtk";

const BlockedAppRow = GObject.registerClass(
  {
    GTypeName: "BlockedAppRow",
    Properties: {
      "window-class": GObject.ParamSpec.string(
        "window-class",
        "Window Class",
        "The window class of the blocked application",
        GObject.ParamFlags.READWRITE,
        ""
      )
    },
    Signals: {
      "delete-requested": {},
      "save-requested": {},
      "input-changed": {}
    }
  },
  class BlockedAppRow2 extends Adw.ExpanderRow {
    windowClass = "";
    inputValue = "";
    originalWindowClass = "";
    windowEntry;
    checkButton;
    deleteButton;

    constructor() {
      super();

      this.set_title("Expand this row to enter window class");
      this.set_subtitle("");

      this.windowEntry = new Adw.EntryRow({
        title: "Window Class",
        text: ""
      });

      this.checkButton = new Gtk.Button({
        icon_name: "object-select-symbolic",
        valign: Gtk.Align.CENTER,
        tooltip_text: "Save and close",
        css_classes: ["flat", "suggested-action"]
      });

      this.deleteButton = new Gtk.Button({
        icon_name: "user-trash-symbolic",
        valign: Gtk.Align.CENTER,
        tooltip_text: "Remove",
        css_classes: ["flat"]
      });

      this.add_suffix(this.checkButton);
      this.add_suffix(this.deleteButton);
      this.add_row(this.windowEntry);

      this.checkButton.visible = false;

      this.checkButton.connect("clicked", () => {
        this.saveChanges();
      });

      this.deleteButton.connect("clicked", () => {
        this.emit("delete-requested");
      });

      this.windowEntry.connect("changed", () => {
        this.inputValue = this.windowEntry.get_text().trim();
        this.updateCheckButtonState();
        this.emit("input-changed");
      });

      this.connect("notify::expanded", () => {
        this.updateButtonVisibility();
      });
    }

    setWindowClass(windowClass) {
      this.windowClass = windowClass;
      this.inputValue = windowClass;
      this.originalWindowClass = windowClass;
      this.windowEntry.set_text(windowClass);
      this.updateDisplay();
      this.updateCheckButtonState();
    }

    getWindowClass() {
      return this.windowClass;
    }

    getInputValue() {
      return this.inputValue;
    }

    getCurrentWindowClass() {
      return this.inputValue.trim() || this.windowClass;
    }

    getOriginalWindowClass() {
      return this.originalWindowClass;
    }

    isEmpty() {
      return this.inputValue.trim() === "";
    }

    closeExpanded() {
      this.set_expanded(false);
    }

    saveChanges() {
      const oldValue = this.windowClass;
      const newValue = this.inputValue.trim();

      if (newValue !== oldValue) {
        this.originalWindowClass = oldValue;
        this.windowClass = newValue;
        this.updateDisplay();
        this.emit("save-requested");
      }

      this.closeExpanded();
    }

    updateButtonVisibility() {
      this.checkButton.visible = this.get_expanded();
      if (this.get_expanded()) {
        this.updateCheckButtonState();
      }
    }

    updateCheckButtonState() {
      this.checkButton.set_sensitive(this.inputValue.trim().length > 0);
    }

    updateDisplay() {
      if (this.windowClass) {
        this.set_title(this.windowClass);
        this.set_subtitle(
          `Expand this row to edit - ${this.windowClass}`
        );
      } else {
        this.set_title("Expand this row to enter window class");
        this.set_subtitle("");
      }
    }
  }
);


export {
  BlockedAppRow
};
