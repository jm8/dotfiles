
import { ExtensionPreferences } from "resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js";

import { AboutPage } from "./prefs/AboutPage.js";
import { GeneralPage } from "./prefs/GeneralPage.js";

class VicinaePrefs extends ExtensionPreferences {
  async fillPreferencesWindow(window) {
    const prefsWindow = window;

    prefsWindow._settings = this.getSettings();

    const generalPage = new GeneralPage();
    generalPage.bindSettings(prefsWindow._settings);
    prefsWindow.add(generalPage);

    const aboutPage = new AboutPage();
    aboutPage.setMetadata(this.metadata);
    prefsWindow.add(aboutPage);
  }
}

export {
  VicinaePrefs as default
};
